package view.bean;

import javax.faces.event.ActionEvent;

import oracle.adf.view.rich.component.rich.layout.RichGridRow;
import oracle.adf.view.rich.component.rich.layout.RichPanelGridLayout;
import oracle.adf.view.rich.component.rich.layout.RichPanelSpringboard;

import oracle.adf.view.rich.component.rich.layout.RichPanelStretchLayout;

import oracle.adf.view.rich.component.rich.layout.RichPanelTabbed;

import org.apache.myfaces.trinidad.component.UIXGroup;
import org.apache.myfaces.trinidad.context.RequestContext;

public class DashBoardBean {
    private RichPanelSpringboard springBoardBinding;
    private RichGridRow gridRowBinding;
    private RichPanelStretchLayout streachLayoutBinding;
    private String status;
    private Boolean show = Boolean.TRUE;
    private RichPanelGridLayout panelmaingirdlayout;
    private RichPanelTabbed paneltabed2;
    private UIXGroup groupbinding;

    public DashBoardBean() {
    }

    public void setSpringBoardBinding(RichPanelSpringboard springBoardBinding) {
        this.springBoardBinding = springBoardBinding;
    }

    public RichPanelSpringboard getSpringBoardBinding() {
        return springBoardBinding;
    }

    public void hideActionL(ActionEvent actionEvent) {
        setShow(Boolean.TRUE);


        System.out.println("TEST *******************");
        RequestContext adfContext = RequestContext.getCurrentInstance();
        // adfContext.addPartialTarget(getPanelmaingirdlayout());
        adfContext.addPartialTarget(getSpringBoardBinding());
        //adfContext.addPartialTarget(getGridRowBinding());
        adfContext.addPartialTarget(getStreachLayoutBinding());
    }


    public void showActionL(ActionEvent actionEvent) {

        setShow(Boolean.FALSE);


        System.out.println("TEST *******************");
        RequestContext adfContext = RequestContext.getCurrentInstance();
        // adfContext.addPartialTarget(getPanelmaingirdlayout());
        adfContext.addPartialTarget(getSpringBoardBinding());
        //  adfContext.addPartialTarget(getGridRowBinding());
        adfContext.addPartialTarget(getStreachLayoutBinding());


    }

    public void setGridRowBinding(RichGridRow gridRowBinding) {
        this.gridRowBinding = gridRowBinding;
    }

    public RichGridRow getGridRowBinding() {
        return gridRowBinding;
    }

    public void setStreachLayoutBinding(RichPanelStretchLayout streachLayoutBinding) {
        this.streachLayoutBinding = streachLayoutBinding;
    }

    public RichPanelStretchLayout getStreachLayoutBinding() {
        return streachLayoutBinding;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setShow(Boolean show) {
        this.show = show;
    }

    public Boolean getShow() {
        return show;
    }

    public void setPanelmaingirdlayout(RichPanelGridLayout panelmaingirdlayout) {
        this.panelmaingirdlayout = panelmaingirdlayout;
    }

    public RichPanelGridLayout getPanelmaingirdlayout() {
        return panelmaingirdlayout;
    }

    public void exitAL(ActionEvent actionEvent) {
        setShow(Boolean.TRUE);


        System.out.println("TEST *******************");
        RequestContext adfContext = RequestContext.getCurrentInstance();
        //   adfContext.addPartialTarget(getPanelmaingirdlayout());
        adfContext.addPartialTarget(getSpringBoardBinding());
        //  adfContext.addPartialTarget(getGridRowBinding());
        adfContext.addPartialTarget(getStreachLayoutBinding());
    }

    public void createAL(ActionEvent actionEvent) {
        setShow(Boolean.FALSE);


        System.out.println("TEST *******************");
        RequestContext adfContext = RequestContext.getCurrentInstance();
        //  adfContext.addPartialTarget(getPanelmaingirdlayout());
        adfContext.addPartialTarget(getSpringBoardBinding());
        adfContext.addPartialTarget(getPaneltabed2());
        adfContext.addPartialTarget(getStreachLayoutBinding());
        adfContext.addPartialTarget(getGroupbinding());
    }

    public void memoInfo() {
        System.out.println("*####################################################");
        System.out.println("***************************************************");

        System.out.println("***********************TEST****************************");

        System.out.println("***************************************************");

    }

    public void setPaneltabed2(RichPanelTabbed paneltabed2) {
        this.paneltabed2 = paneltabed2;
    }

    public RichPanelTabbed getPaneltabed2() {
        return paneltabed2;
    }

    public void setGroupbinding(UIXGroup groupbinding) {
        this.groupbinding = groupbinding;
    }

    public UIXGroup getGroupbinding() {
        return groupbinding;
    }
}
